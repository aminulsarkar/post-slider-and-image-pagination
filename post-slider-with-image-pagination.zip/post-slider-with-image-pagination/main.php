<?php
/**
 * Plugin Name: Post Slider with Image Pagination
 * Plugin URI: https://github.com/aminulsarkar/post-slider-and-image-pagination
 * Description: Description: WordPress post slider plugin with featured image pagination. Display post thumbnails as slider navigation for posts, pages, and custom post types.
 * Version: 1.0.0
 * Author: Aminul Sarkar
 * Author URI: https://aminulsarkar.com
 * Text Domain: rpsw
 * Domain Path: /languages
 */


if (!defined('ABSPATH')) exit;

define('RPSW_PATH', plugin_dir_path(__FILE__));
define('RPSW_URL', plugin_dir_url(__FILE__));

class RPSW_Plugin {

    public function __construct() {
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('init', [$this, 'register_shortcodes']);
        add_action('init', [$this, 'register_custom_post_types']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
    }
    
    // Translation
    public function load_textdomain() {
    load_plugin_textdomain(
        'rpsw',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
}

    // Resiter scripts and styles
    public function register_assets() {

    // Swiper
    wp_register_style(
        'rpsw-swiper',
        'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
        [],
        '11.0.0'
    );

    wp_register_script(
        'rpsw-swiper',
        'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
        [],
        '11.0.0',
        true
    );

    // Plugin assets
    wp_register_style(
        'rpsw-style',
        RPSW_URL . 'assets/css/swiper-style.css',
        ['rpsw-swiper'],
        '1.0.0'
    );

    wp_register_script(
        'rpsw-script',
        RPSW_URL . 'assets/js/swiper-init.js',
        ['jquery', 'rpsw-swiper'],
        '1.0.0',
        true
    );

    wp_register_script(
        'rpsw-vertical',
        RPSW_URL . 'assets/js/swiper-init-vertical.js',
        ['jquery', 'rpsw-swiper'],
        '1.0.0',
        true
    );
}


    // Register Shortcodes
    public function register_shortcodes() {
        require_once RPSW_PATH . 'includes/shortcode-recent-posts-slider.php';
        require_once RPSW_PATH . 'includes/shortcode-recent-posts-slider-vertical.php';
    }
    
    // Register Post Types
    public function register_custom_post_types() {
        require_once RPSW_PATH . 'includes/register-custom-post-types.php';
    }
}

new RPSW_Plugin();
