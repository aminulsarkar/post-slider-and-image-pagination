<?php
if (!defined('ABSPATH')) exit;

add_shortcode('recent_posts_swiper_horizontal', function ($atts) {
    
    wp_enqueue_script('rpsw-swipert');
    wp_enqueue_style('rpsw-style');
    wp_enqueue_script('rpsw-script');
    wp_enqueue_script('rpsw-vertical');

    $atts = shortcode_atts([
        'posts' => 6,
        'category' => '',
    ], $atts);

    $args = [
        'post_type' => 'post',
        'posts_per_page' => (int) $atts['posts'],
        'post_status' => 'publish',
    ];

    if (!empty($atts['category'])) {
        $args['category_name'] = $atts['category'];
    }

    $query = new WP_Query($args);

    if (!$query->have_posts()) return '';

    ob_start();
    ?>

    <div class="rpsw-wrapper rpsw-horizontal">

        <!-- Main Swiper -->
        <div class="swiper rpsw-main">
            <div class="swiper-wrapper">

                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="swiper-slide">
                            <a href="<?php the_permalink(); ?>" class="rpsw-slide-link">
                                <?php the_post_thumbnail('large'); ?>

                                <div class="rpsw-overlay">
                                    <?php
$categories = get_the_category();

if (!empty($categories)) :
?>
    <div class="rpsw-categories">
        <?php foreach ($categories as $cat) : ?>
            <a
                href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"
                class="rpsw-category-btn"
            >
                <?php echo esc_html($cat->name); ?>
            </a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
                                    <h3 class="rpsw-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <div class="rps-date">
                <?php echo esc_html(get_the_date()); ?>
            </div>

            <div class="rps-excerpt">
                <?php echo esc_html(wp_trim_words(get_the_excerpt(), 10, '…')); ?>
            </div>
                                    <a href="<?php echo esc_url(get_permalink()); ?>"><span class="rpsw-readmore"><?php esc_html_e('Read More →', 'rpsw'); ?></span></a>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endwhile; ?>

            </div>

            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>

        <!-- Thumbs Swiper -->
        <div class="swiper rpsw-thumbs">
            <div class="swiper-wrapper">

                <?php
                $query->rewind_posts();
                while ($query->have_posts()) : $query->the_post();
                $title_words = wp_trim_words(get_the_title(), 5, '');
                ?>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="swiper-slide">
                            <?php the_post_thumbnail('thumbnail'); ?>
                        </div>
                    <?php endif; ?>
                <?php endwhile; ?>

            </div>
        </div>

    </div>

    <?php
    wp_reset_postdata();
    return ob_get_clean();
});
