<?php
if (!defined('ABSPATH')) exit;

/**
 * Register Service Post Type
 */
register_post_type('service', [
    'labels' => [
        'name'               => __('Services', 'rpsw'),
        'singular_name'      => __('Service', 'rpsw'),
        'menu_name'          => __('Services', 'rpsw'),
        'add_new_item'       => __('Add New Service', 'rpsw'),
        'edit_item'          => __('Edit Service', 'rpsw'),
        'new_item'           => __('New Service', 'rpsw'),
        'view_item'          => __('View Service', 'rpsw'),
        'search_items'       => __('Search Services', 'rpsw'),
        'not_found'          => __('No Services found', 'rpsw'),
        'not_found_in_trash' => __('No Services found in Trash', 'rpsw'),
    ],
    'public'        => true,
    'show_ui'       => true,
    'show_in_menu'  => true,
    'menu_icon'     => 'dashicons-admin-tools',
    'supports'      => ['title', 'editor', 'thumbnail', 'excerpt'],
    'has_archive'   => true,
    'rewrite'       => ['slug' => 'services'],
    'show_in_rest'  => true, // Elementor + Gutenberg
]);

/**
 * Service Categories (Hierarchical)
 */
register_taxonomy('service_category', ['service'], [
    'labels' => [
        'name'              => __('Service Categories', 'rpsw'),
        'singular_name'     => __('Service Category', 'rpsw'),
        'search_items'      => __('Search Service Categories', 'rpsw'),
        'all_items'         => __('All Service Categories', 'rpsw'),
        'parent_item'       => __('Parent Service Category', 'rpsw'),
        'parent_item_colon' => __('Parent Service Category:', 'rpsw'),
        'edit_item'         => __('Edit Service Category', 'rpsw'),
        'update_item'       => __('Update Service Category', 'rpsw'),
        'add_new_item'      => __('Add New Service Category', 'rpsw'),
        'menu_name'         => __('Service Categories', 'rpsw'),
    ],
    'hierarchical' => true,
    'public'       => true,
    'show_ui'      => true,
    'show_in_rest' => true,
    'rewrite'      => ['slug' => 'service-category'],
]);

/**
 * Service Tags (Non-hierarchical)
 */
register_taxonomy('service_tag', ['service'], [
    'labels' => [
        'name'                       => __('Service Tags', 'rpsw'),
        'singular_name'              => __('Service Tag', 'rpsw'),
        'search_items'               => __('Search Service Tags', 'rpsw'),
        'popular_items'              => __('Popular Service Tags', 'rpsw'),
        'all_items'                  => __('All Service Tags', 'rpsw'),
        'edit_item'                  => __('Edit Service Tag', 'rpsw'),
        'update_item'                => __('Update Service Tag', 'rpsw'),
        'add_new_item'               => __('Add New Service Tag', 'rpsw'),
        'menu_name'                  => __('Service Tags', 'rpsw'),
    ],
    'hierarchical' => false,
    'public'       => true,
    'show_ui'      => true,
    'show_in_rest' => true,
    'rewrite'      => ['slug' => 'service-tag'],
]);


?>