document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('.rpsw-wrapper.rpsw-vertical').forEach(function (wrapper) {

    const thumbsSwiper = new Swiper(wrapper.querySelector('.rpsw-vertical .rpsw-thumbs'), {
      direction: 'vertical',
      slidesPerView: 'auto',
      spaceBetween: 10,
      watchSlidesProgress: true,
      freeMode: true,

      breakpoints: {
        0: { direction: 'horizontal' },
        769: { direction: 'vertical' }
      }
    });

    new Swiper(wrapper.querySelector('.rpsw-vertical .rpsw-main'), {
        loop: true,
      spaceBetween: 10,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
        pauseOnMouseEnter: true,
      },
      speed: 800,
      effect: 'fade',
      grabCursor: false,
      watchSlidesProgress: true,
      navigation: {
        nextEl: wrapper.querySelector('.rpsw-vertical .swiper-button-next'),
        prevEl: wrapper.querySelector('.rpsw-vertical .swiper-button-prev'),
      },
      thumbs: {
        swiper: thumbsSwiper,
      },
    });

  });

});