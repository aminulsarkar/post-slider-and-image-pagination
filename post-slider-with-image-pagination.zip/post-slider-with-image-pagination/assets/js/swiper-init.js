document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('.rpsw-wrapper.rpsw-horizontal').forEach(function (wrapper) {

    const thumbs = new Swiper(wrapper.querySelector('.rpsw-horizontal .rpsw-thumbs'), {
      slidesPerView: 'auto',
      spaceBetween: 10,
      watchSlidesProgress: true,
      freeMode: true,
    });

    new Swiper(wrapper.querySelector('.rpsw-horizontal .rpsw-main'), {
      spaceBetween: 10,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
        pauseOnMouseEnter: true,
      },
      speed: 800,
      effect: 'fade',
      grabCursor: false,
      watchSlidesProgress: true,
      navigation: {
        nextEl: wrapper.querySelector('.rpsw-horizontal .swiper-button-next'),
        prevEl: wrapper.querySelector('.rpsw-horizontal .swiper-button-prev'),
      },
      thumbs: {
        swiper: thumbs,
      },
    });

  });

});